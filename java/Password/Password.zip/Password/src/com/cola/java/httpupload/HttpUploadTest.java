package com.cola.java.httpupload;

import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class HttpUploadTest {

	private static final String UPLOAD_URL = "http://192.168.200.15:8888/upload/?key=649D4B8F0429FF54E035C4B6BB70BF6586EE6E0A0C31013322628B8153029E20BC0CE8A994C2CF78490AE398A1DD2740";

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {

		DataInputStream dis = null;
		String filePath = "D:\\123.mp4";
		URL url = new URL(UPLOAD_URL);
		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		connection.setReadTimeout(100000);
		connection.setDoInput(true);
		connection.setDoOutput(true);
		connection.setRequestMethod("POST");
		connection.addRequestProperty("Host", "192.168.200.15");
//		connection.addRequestProperty("Content-Length", "20971520"/*"10634380"*/);
		connection.addRequestProperty("Content-Range",
				"bytes 0-10634379/10634380");
		connection.setRequestProperty("Content-MD5",
				"29a0713ef07976392c279a08058c9c8a");
		connection.setRequestProperty("Content-Type",
				"application/octet-stream");
		BufferedOutputStream out = new BufferedOutputStream(
				connection.getOutputStream());
		
//		DataOutputStream out = new DataOutputStream(connection.getOutputStream());

		// ��ȡ�ļ��ϴ���������
		File file = new File(filePath);
		FileInputStream fileInputStream = new FileInputStream(file);
		FileOutputStream fos = new FileOutputStream("d:\\test.bin");
		byte[] buf = new byte[1024];
		int len = 0;
		while ((len = fileInputStream.read(buf)) != -1) {
			out.write(buf, 0, len);
			fos.write(buf, 0 , len);
		}
		out.flush();
		out.close();
		fileInputStream.close();
		fos.flush();
		fos.close();
				
		if ((connection.getResponseCode() != 200) && (connection.getResponseCode() != 206)) {
			System.out.println(connection.getResponseCode());
			dis = new DataInputStream(connection.getErrorStream());
			byte[] bufIn = new byte[1024];
			int length = 0;
			while ((length = dis.read(bufIn)) != -1) {
				System.out.println(new String(bufIn, 0, length));
			}
			dis.close();
		} else {
			System.out.println(connection.getResponseCode());
			dis = new DataInputStream(connection.getInputStream());
			byte[] bufIn = new byte[1024];
			int length = 0;
			while ((length = dis.read(bufIn)) != -1) {
				System.out.println(new String(bufIn, 0, length));
			}
			dis.close();
		}

	}

}
